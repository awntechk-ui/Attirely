import 'package:flutter/material.dart';
import 'Common_Screens/UI/splash_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(const AttirelyApp());
}

class AttirelyApp extends StatelessWidget {
  const AttirelyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Attirely',

      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: Colors.black,
      ),

      home: const SplashScreen(),
    );
  }
}